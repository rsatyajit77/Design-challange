import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox from "../components/MaterialFixedLabelTextbox";
import MaterialButtonGrey from "../components/MaterialButtonGrey";
import MaterialButtonPrimary1 from "../components/MaterialButtonPrimary1";

function Setting(props) {
  return (
    <Rect>
      <SuggestionBoxList1>Suggestion box Setting</SuggestionBoxList1>
      <Rect2>
        <SuggestionBoxList2Row>
          <SuggestionBoxList2>Change Box Description</SuggestionBoxList2>
          <GenerateURl>Generate URl</GenerateURl>
          <SetPassword>Set password</SetPassword>
        </SuggestionBoxList2Row>
        <Rect3></Rect3>
      </Rect2>
      <Rect4>
        <AddDescriptionRow>
          <AddDescription>Add Description</AddDescription>
          <MaterialFixedLabelTextbox
            style={{
              height: 83,
              width: 375,
              borderWidth: 1,
              borderColor: "rgba(136,136,136,1)",
              marginLeft: 24,
              borderStyle: "solid"
            }}
          ></MaterialFixedLabelTextbox>
        </AddDescriptionRow>
        <AddLogoRow>
          <AddLogo>Add Logo</AddLogo>
          <MaterialFixedLabelTextbox
            style={{
              height: 83,
              width: 112,
              borderWidth: 1,
              borderColor: "rgba(136,136,136,1)",
              marginLeft: 84,
              borderStyle: "solid"
            }}
          ></MaterialFixedLabelTextbox>
          <MaxSize512Kb>Max Size 512 kb</MaxSize512Kb>
        </AddLogoRow>
      </Rect4>
      <MaterialButtonGreyRow>
        <MaterialButtonGrey
          style={{
            height: 36,
            width: 100
          }}
        ></MaterialButtonGrey>
        <MaterialButtonPrimary1
          style={{
            height: 36,
            width: 100,
            marginLeft: 42
          }}
        ></MaterialButtonPrimary1>
      </MaterialButtonGreyRow>
    </Rect>
  );
}

const Rect = styled.div`
  display: flex;
  width: 956px;
  height: 516px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(138,137,137,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  margin-top: 58px;
  margin-left: 90px;
`;

const SuggestionBoxList1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-top: 38px;
  margin-left: 10px;
`;

const Rect2 = styled.div`
  width: 956px;
  height: 98px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(186,186,186,1);
  flex-direction: column;
  display: flex;
  margin-top: 27px;
  border-style: solid;
`;

const SuggestionBoxList2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
`;

const GenerateURl = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-left: 136px;
`;

const SetPassword = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-left: 187px;
`;

const SuggestionBoxList2Row = styled.div`
  height: 20px;
  flex-direction: row;
  display: flex;
  margin-top: 42px;
  margin-left: 24px;
  margin-right: 64px;
`;

const Rect3 = styled.div`
  width: 290px;
  height: 13px;
  background-color: rgba(20,161,223,1);
  margin-top: 23px;
  margin-left: 14px;
`;

const Rect4 = styled.div`
  width: 956px;
  height: 246px;
  border-width: 1px;
  border-color: rgba(186,186,186,1);
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const AddDescription = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 18px;
  line-height: 20px;
  margin-top: 63px;
`;

const AddDescriptionRow = styled.div`
  height: 83px;
  flex-direction: row;
  display: flex;
  margin-top: 34px;
  margin-left: 39px;
  margin-right: 389px;
`;

const AddLogo = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 18px;
  line-height: 20px;
  margin-top: 41px;
`;

const MaxSize512Kb = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 16px;
  line-height: 20px;
  margin-left: 22px;
  margin-top: 63px;
`;

const AddLogoRow = styled.div`
  height: 83px;
  flex-direction: row;
  display: flex;
  margin-top: 21px;
  margin-left: 30px;
  margin-right: 512px;
`;

const MaterialButtonGreyRow = styled.div`
  height: 36px;
  flex-direction: row;
  display: flex;
  margin-top: 25px;
  margin-left: 677px;
  margin-right: 37px;
`;

export default Setting;
