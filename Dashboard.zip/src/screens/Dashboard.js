import React, { Component } from "react";
import styled, { css } from "styled-components";

function Dashboard(props) {
  return (
    <>
      <ButtonRow>
        <Button>
          <ButtonOverlay>
            <TotalSuggestionsColumn>
              <TotalSuggestions>Total Suggestions</TotalSuggestions>
              <ViewReportRow>
                <ViewReport>View Report</ViewReport>
                <Image2 src={require("../assets/images/total.png")}></Image2>
              </ViewReportRow>
            </TotalSuggestionsColumn>
            <TotalSuggestions1>300</TotalSuggestions1>
          </ButtonOverlay>
        </Button>
        <Button1>
          <ButtonOverlay>
            <TotalSuggestions3Column>
              <TotalSuggestions3>In Progress Suggestions</TotalSuggestions3>
              <ViewReport1Row>
                <ViewReport1>View Report</ViewReport1>
                <Image3
                  src={require("../assets/images/icons-progress.png")}
                ></Image3>
              </ViewReport1Row>
            </TotalSuggestions3Column>
            <TotalSuggestions2>300</TotalSuggestions2>
          </ButtonOverlay>
        </Button1>
        <Button2>
          <ButtonOverlay>
            <ArchivedSuggestionsColumn>
              <ArchivedSuggestions>Archived Suggestions</ArchivedSuggestions>
              <ViewReport2Row>
                <ViewReport2>View Report</ViewReport2>
                <Image4 src={require("../assets/images/archive1.png")}></Image4>
              </ViewReport2Row>
            </ArchivedSuggestionsColumn>
            <TotalSuggestions4>300</TotalSuggestions4>
          </ButtonOverlay>
        </Button2>
        <Button3Stack>
          <Button3>
            <ButtonOverlay>
              <ViewReport3Row>
                <ViewReport3>View Report</ViewReport3>
                <Image5 src={require("../assets/images/top1.png")}></Image5>
              </ViewReport3Row>
              <TotalSuggestions5>300</TotalSuggestions5>
            </ButtonOverlay>
          </Button3>
          <ArchivedSuggestions1>Top Viewed Suggestions</ArchivedSuggestions1>
        </Button3Stack>
      </ButtonRow>
      <Rect>
        <Image6Row>
          <Image6 src={require("../assets/images/logo.png")}></Image6>
          <Group>
            <Text>Dashboard</Text>
            <Logout>Logout</Logout>
            <Setting>Setting</Setting>
          </Group>
        </Image6Row>
      </Rect>
      <Image7 src={require("../assets/images/logo.png")}></Image7>
    </>
  );
}

const Button = styled.div`
  width: 290px;
  height: 198px;
  background-color: rgba(19,182,106,1);
  overflow: hidden;
  border-width: 1px;
  border-color: rgba(252,252,252,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  display: flex;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const TotalSuggestions = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 20px;
  font-size: 22px;
`;

const ViewReport = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 400;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 20px;
  margin-top: 54px;
  margin-bottom: 46px;
`;

const Image2 = styled.img`
  width: 100%;
  height: 100px;
  margin-left: 49px;
  object-fit: contain;
`;

const ViewReportRow = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 37px;
`;

const TotalSuggestionsColumn = styled.div`
  flex-direction: column;
  margin-top: 32px;
  margin-left: 18px;
  margin-right: 15px;
  display: flex;
`;

const TotalSuggestions1 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 45px;
  flex: 1 1 0%;
  margin-bottom: 120px;
  margin-top: -111px;
  margin-left: 18px;
  display: flex;
  flex-direction: column;
`;

const Button1 = styled.div`
  width: 290px;
  height: 198px;
  background-color: rgba(172,67,221,1);
  overflow: hidden;
  border-width: 1px;
  border-color: rgba(252,252,252,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  display: flex;
  margin-left: 11px;
`;

const TotalSuggestions3 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 20px;
  font-size: 22px;
`;

const ViewReport1 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 400;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 20px;
  margin-top: 54px;
  margin-bottom: 46px;
`;

const Image3 = styled.img`
  width: 100%;
  height: 100px;
  margin-left: 55px;
  object-fit: contain;
`;

const ViewReport1Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 37px;
`;

const TotalSuggestions3Column = styled.div`
  flex-direction: column;
  margin-top: 32px;
  margin-left: 16px;
  margin-right: 11px;
  display: flex;
`;

const TotalSuggestions2 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 45px;
  flex: 1 1 0%;
  margin-bottom: 120px;
  margin-top: -111px;
  margin-left: 16px;
  display: flex;
  flex-direction: column;
`;

const Button2 = styled.div`
  width: 290px;
  height: 198px;
  background-color: rgba(183,104,48,1);
  overflow: hidden;
  border-width: 1px;
  border-color: rgba(252,252,252,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  display: flex;
  margin-left: 7px;
`;

const ArchivedSuggestions = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 20px;
  font-size: 22px;
`;

const ViewReport2 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 400;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 20px;
  margin-top: 54px;
  margin-bottom: 46px;
`;

const Image4 = styled.img`
  width: 100%;
  height: 100px;
  margin-left: 42px;
  object-fit: contain;
`;

const ViewReport2Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 37px;
`;

const ArchivedSuggestionsColumn = styled.div`
  flex-direction: column;
  margin-top: 32px;
  margin-left: 29px;
  margin-right: 11px;
  display: flex;
`;

const TotalSuggestions4 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 45px;
  flex: 1 1 0%;
  margin-bottom: 120px;
  margin-top: -111px;
  margin-left: 29px;
  display: flex;
  flex-direction: column;
`;

const Button3 = styled.div`
  top: 0px;
  left: 0px;
  width: 290px;
  height: 198px;
  position: absolute;
  background-color: rgba(206,87,78,1);
  overflow: hidden;
  border-width: 1px;
  border-color: rgba(252,252,252,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  display: flex;
`;

const ViewReport3 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 400;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 20px;
  margin-top: 54px;
  margin-bottom: 47px;
`;

const Image5 = styled.img`
  width: 100%;
  height: 100px;
  margin-left: 24px;
  object-fit: contain;
`;

const ViewReport3Row = styled.div`
  height: 101px;
  flex-direction: row;
  display: flex;
  margin-top: 89px;
  margin-left: 23px;
  margin-right: 31px;
`;

const TotalSuggestions5 = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 28px;
  font-size: 45px;
  flex: 1 1 0%;
  margin-bottom: 120px;
  margin-top: -112px;
  margin-left: 23px;
  display: flex;
  flex-direction: column;
`;

const ArchivedSuggestions1 = styled.span`
  font-family: System;
  top: 32px;
  left: 23px;
  position: absolute;
  font-style: normal;
  font-weight: 600;
  color: rgba(245,235,235,1);
  line-height: 20px;
  font-size: 22px;
`;

const Button3Stack = styled.div`
  width: 291px;
  height: 198px;
  margin-left: 16px;
  position: relative;
`;

const ButtonRow = styled.div`
  height: 198px;
  flex-direction: row;
  display: flex;
  margin-top: 84px;
  margin-left: 12px;
  margin-right: 7px;
`;

const Rect = styled.div`
  width: 1214px;
  height: 71px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(19,128,246,1);
  flex-direction: row;
  display: flex;
  margin-top: -282px;
  border-style: solid;
`;

const Image6 = styled.img`
  width: 100%;
  height: 45px;
  object-fit: contain;
`;

const Group = styled.div`
  width: 284px;
  height: 23px;
  flex-direction: row;
  justify-content: space-between;
  margin-left: 840px;
  margin-top: 11px;
  display: flex;
`;

const Text = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 500;
  color: #121212;
  line-height: 24px;
  font-size: 18px;
`;

const Logout = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 500;
  color: #121212;
  line-height: 24px;
  font-size: 18px;
`;

const Setting = styled.span`
  font-family: System;
  font-style: normal;
  font-weight: 500;
  color: #121212;
  line-height: 24px;
  font-size: 18px;
`;

const Image6Row = styled.div`
  height: 45px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 22px;
  margin-left: 23px;
  margin-top: 13px;
`;

const Image7 = styled.img`
  width: 45px;
  height: 45px;
  margin-top: -504px;
  object-fit: contain;
`;

export default Dashboard;
