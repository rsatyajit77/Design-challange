import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialSwitch from "../components/MaterialSwitch";
import MaterialStackedLabelTextbox1 from "../components/MaterialStackedLabelTextbox1";
import MaterialStackedLabelTextbox2 from "../components/MaterialStackedLabelTextbox2";
import MaterialStackedLabelTextbox3 from "../components/MaterialStackedLabelTextbox3";
import MaterialStackedLabelTextbox4 from "../components/MaterialStackedLabelTextbox4";
import MaterialButtonGrey from "../components/MaterialButtonGrey";
import MaterialButtonPrimary1 from "../components/MaterialButtonPrimary1";

function BoxSharing(props) {
  return (
    <Rect>
      <SuggestionBoxList1>Suggestion box Sharing</SuggestionBoxList1>
      <Rect2>
        <ShareIdeasRow>
          <ShareIdeas>Share Ideas</ShareIdeas>
          <ViewIdeas>View Ideas</ViewIdeas>
        </ShareIdeasRow>
        <Rect3></Rect3>
      </Rect2>
      <SetAnanomousRow>
        <SetAnanomous>Set Ananomous</SetAnanomous>
        <MaterialSwitch
          style={{
            width: 45,
            height: 23,
            marginLeft: 12
          }}
        ></MaterialSwitch>
      </SetAnanomousRow>
      <MaterialStackedLabelTextbox1Row>
        <MaterialStackedLabelTextbox1
          style={{
            height: 60,
            width: 375
          }}
        ></MaterialStackedLabelTextbox1>
        <MaterialStackedLabelTextbox2
          style={{
            height: 60,
            width: 375,
            marginLeft: 134
          }}
        ></MaterialStackedLabelTextbox2>
      </MaterialStackedLabelTextbox1Row>
      <MaterialStackedLabelTextbox3Row>
        <MaterialStackedLabelTextbox3
          style={{
            height: 60,
            width: 375
          }}
        ></MaterialStackedLabelTextbox3>
        <MaterialStackedLabelTextbox4
          style={{
            height: 60,
            width: 375,
            marginLeft: 134
          }}
        ></MaterialStackedLabelTextbox4>
      </MaterialStackedLabelTextbox3Row>
      <MaterialButtonGreyRow>
        <MaterialButtonGrey
          style={{
            height: 36,
            width: 100
          }}
        ></MaterialButtonGrey>
        <MaterialButtonPrimary1
          style={{
            height: 36,
            width: 100,
            marginLeft: 42
          }}
        ></MaterialButtonPrimary1>
      </MaterialButtonGreyRow>
    </Rect>
  );
}

const Rect = styled.div`
  display: flex;
  width: 956px;
  height: 516px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(138,137,137,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  margin-top: 58px;
  margin-left: 90px;
`;

const SuggestionBoxList1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-top: 38px;
  margin-left: 10px;
`;

const Rect2 = styled.div`
  width: 956px;
  height: 98px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(186,186,186,1);
  flex-direction: column;
  display: flex;
  margin-top: 27px;
  border-style: solid;
`;

const ShareIdeas = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
`;

const ViewIdeas = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-left: 594px;
  margin-top: 7px;
`;

const ShareIdeasRow = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 42px;
  margin-left: 40px;
  margin-right: 78px;
`;

const Rect3 = styled.div`
  width: 250px;
  height: 13px;
  background-color: rgba(20,161,223,1);
  margin-top: 16px;
  margin-left: 14px;
`;

const SetAnanomous = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 18px;
  line-height: 20px;
`;

const SetAnanomousRow = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  margin-top: 24px;
  margin-left: 30px;
  margin-right: 741px;
`;

const MaterialStackedLabelTextbox1Row = styled.div`
  height: 60px;
  flex-direction: row;
  display: flex;
  margin-top: 14px;
  margin-left: 30px;
  margin-right: 42px;
`;

const MaterialStackedLabelTextbox3Row = styled.div`
  height: 60px;
  flex-direction: row;
  display: flex;
  margin-top: 47px;
  margin-left: 30px;
  margin-right: 42px;
`;

const MaterialButtonGreyRow = styled.div`
  height: 36px;
  flex-direction: row;
  display: flex;
  margin-top: 43px;
  margin-left: 677px;
  margin-right: 37px;
`;

export default BoxSharing;
