import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox from "../components/MaterialFixedLabelTextbox";

function SharingControl(props) {
  return (
    <Rect>
      <SuggestionBoxList1>Suggestion box Sharing</SuggestionBoxList1>
      <Rect2>
        <SharableLinkRow>
          <SharableLink>Sharable Link</SharableLink>
          <SharableIconCode>Sharable Icon Code</SharableIconCode>
          <DownloadIconCode>Download Icon Code</DownloadIconCode>
        </SharableLinkRow>
        <Rect3></Rect3>
      </Rect2>
      <Rect4>
        <MaterialFixedLabelTextboxStack>
          <MaterialFixedLabelTextbox
            style={{
              height: 83,
              width: 956,
              position: "absolute",
              left: 0,
              top: 0,
              borderWidth: 1,
              borderColor: "rgba(136,136,136,1)",
              borderStyle: "solid"
            }}
          ></MaterialFixedLabelTextbox>
          <SuggestionBoxList2>www.suggestion.box.tips</SuggestionBoxList2>
          <Image>
            <Image2 src={require("../assets/images/arrow_next1.png")}></Image2>
          </Image>
        </MaterialFixedLabelTextboxStack>
        <WwwSboxBoxTipsRow>
          <WwwSboxBoxTips>www.sbox.box.tips</WwwSboxBoxTips>
          <Image1 src={require("../assets/images/arrow_next1.png")}></Image1>
        </WwwSboxBoxTipsRow>
      </Rect4>
    </Rect>
  );
}

const Rect = styled.div`
  display: flex;
  width: 956px;
  height: 349px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(138,137,137,1);
  border-style: solid;
  border-radius: 16px;
  flex-direction: column;
  margin-top: 58px;
  margin-left: 90px;
`;

const SuggestionBoxList1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-top: 38px;
  margin-left: 10px;
`;

const Rect2 = styled.div`
  width: 956px;
  height: 98px;
  background-color: rgba(255,255,255,1);
  border-width: 1px;
  border-color: rgba(186,186,186,1);
  flex-direction: column;
  display: flex;
  margin-top: 27px;
  border-style: solid;
`;

const SharableLink = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
`;

const SharableIconCode = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-left: 205px;
`;

const DownloadIconCode = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-left: 109px;
`;

const SharableLinkRow = styled.div`
  height: 20px;
  flex-direction: row;
  display: flex;
  margin-top: 42px;
  margin-left: 40px;
  margin-right: 27px;
`;

const Rect3 = styled.div`
  width: 250px;
  height: 13px;
  background-color: rgba(20,161,223,1);
  margin-top: 23px;
  margin-left: 14px;
`;

const Rect4 = styled.div`
  width: 956px;
  height: 166px;
  border-width: 1px;
  border-color: rgba(186,186,186,1);
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const SuggestionBoxList2 = styled.span`
  font-family: Roboto;
  top: 32px;
  left: 26px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
`;

const Image = styled.div`
  top: 16px;
  left: 874px;
  width: 55px;
  height: 55px;
  position: absolute;
  flex-direction: column;
  display: flex;
  background-image: url(${require("../assets/images/arrow_next1.png")});
  background-size: cover;
`;

const Image2 = styled.img`
  width: 55px;
  height: 100%;
  object-fit: contain;
`;

const MaterialFixedLabelTextboxStack = styled.div`
  width: 956px;
  height: 83px;
  position: relative;
`;

const WwwSboxBoxTips = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
  line-height: 20px;
  margin-top: 17px;
`;

const Image1 = styled.img`
  width: 100%;
  height: 55px;
  margin-left: 645px;
  object-fit: contain;
`;

const WwwSboxBoxTipsRow = styled.div`
  height: 55px;
  flex-direction: row;
  display: flex;
  margin-top: 14px;
  margin-left: 26px;
  margin-right: 27px;
`;

export default SharingControl;
