import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";

function MaterialRightIconTextbox(props) {
  return (
    <Container {...props}>
      <InputStyle placeholder="Status By"></InputStyle>
      <MaterialCommunityIconsIcon
        name="arrow-down-bold"
        style={{
          color: "#616161",
          fontSize: 24,
          paddingRight: 8
        }}
      ></MaterialCommunityIconsIcon>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-bottom-width: 1px;
  border-color: #D9D5DC;
  background-color: transparent;
  flex-direction: row;
  align-items: center;
`;

const InputStyle = styled.input`
  font-family: Roboto;
  color: #000;
  padding-right: 16px;
  font-size: 16px;
  align-self: stretch;
  line-height: 16px;
  padding-top: 14px;
  padding-bottom: 8px;
  width: 183px;
  border: none;
  background: transparent;
`;

export default MaterialRightIconTextbox;
