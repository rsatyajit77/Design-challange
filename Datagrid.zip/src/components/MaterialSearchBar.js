import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";

function MaterialSearchBar(props) {
  return (
    <Container {...props}>
      <Rect1>
        <LeftIconButton>
          <ButtonOverlay>
            <MaterialCommunityIconsIcon
              name="magnify"
              style={{
                backgroundColor: "transparent",
                color: "#000",
                fontSize: 24,
                opacity: 0.6
              }}
            ></MaterialCommunityIconsIcon>
          </ButtonOverlay>
        </LeftIconButton>
        <InputStyleStack>
          <InputStyle placeholder="SuggestionBox Name"></InputStyle>
          <RightIconButton>
            <ButtonOverlay>
              <MaterialCommunityIconsIcon
                name="arrow-right-bold"
                style={{
                  backgroundColor: "transparent",
                  color: "#000",
                  fontSize: 24,
                  opacity: 0.6
                }}
              ></MaterialCommunityIconsIcon>
            </ButtonOverlay>
          </RightIconButton>
        </InputStyleStack>
      </Rect1>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: #3F51B5;
  padding: 4px;
  flex-direction: column;
  box-shadow: 0px 2px 1.2px  0.2px #111 ;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Rect1 = styled.div`
  flex-direction: row;
  align-items: center;
  background-color: rgba(230, 230, 230,1);
  flex: 1 1 0%;
  margin-bottom: 1px;
  margin-top: 3px;
  margin-left: 3px;
  margin-right: 3px;
  display: flex;
`;

const LeftIconButton = styled.div`
  padding: 11px;
  flex-direction: column;
  display: flex;
  margin-left: 5px;
  margin-top: 5px;
  border: none;
`;

const InputStyle = styled.input`
  font-family: Roboto;
  height: 48px;
  color: #000;
  padding-right: 5px;
  font-size: 16px;
  align-self: flex-start;
  width: 258px;
  line-height: 16px;
  position: absolute;
  left: 0px;
  top: 1px;
  border: none;
  background: transparent;
`;

const RightIconButton = styled.div`
  padding: 11px;
  position: absolute;
  right: 0px;
  align-items: center;
  top: 0px;
  flex-direction: column;
  display: flex;
  border: none;
`;

const InputStyleStack = styled.div`
  width: 297px;
  height: 49px;
  margin-left: 21px;
  margin-top: 3px;
  position: relative;
`;

export default MaterialSearchBar;
