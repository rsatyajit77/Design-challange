import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialIconTextbox from "../components/MaterialIconTextbox";
import MaterialSearchBar from "../components/MaterialSearchBar";
import MaterialRightIconTextbox from "../components/MaterialRightIconTextbox";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function Datagrid(props) {
  return (
    <>
      <Rect>
        <SuggestionBoxListStackRow>
          <SuggestionBoxListStack>
            <SuggestionBoxList>Suggestion box List</SuggestionBoxList>
            <SuggestionBoxList1>Suggestion box List</SuggestionBoxList1>
          </SuggestionBoxListStack>
          <MaterialIconTextboxStack>
            <MaterialIconTextbox
              style={{
                height: 43,
                width: 244,
                position: "absolute",
                left: 0,
                top: 0,
                borderWidth: 1,
                borderColor: "rgba(135,135,135,1)",
                borderStyle: "solid"
              }}
            ></MaterialIconTextbox>
            <Rect4>
              <Rect3>
                <Image5
                  src={require("../assets/images/arrow_next.png")}
                ></Image5>
              </Rect3>
            </Rect4>
          </MaterialIconTextboxStack>
          <MaterialSearchBar
            style={{
              height: 56,
              width: 375,
              marginLeft: 10
            }}
          ></MaterialSearchBar>
        </SuggestionBoxListStackRow>
      </Rect>
      <TotalSuggestionRow>
        <TotalSuggestion>Total Suggestion :</TotalSuggestion>
        <MaterialRightIconTextbox
          style={{
            height: 43,
            width: 228,
            borderWidth: 1,
            borderColor: "rgba(100,100,100,1)",
            marginLeft: 708,
            borderStyle: "solid"
          }}
        ></MaterialRightIconTextbox>
        <MaterialButtonPrimary
          style={{
            height: 43,
            width: 100,
            marginLeft: 10
          }}
        ></MaterialButtonPrimary>
      </TotalSuggestionRow>
      <Rect2>
        <Box2>Box Name Responce Status View Action</Box2>
      </Rect2>
      <ImageRow>
        <Image src={require("../assets/images/apple-touch-icon.png")}></Image>
        <Box3>Design Thinking 20 open 40</Box3>
        <Group>
          <Image1 src={require("../assets/images/view.png")}></Image1>
          <Image2 src={require("../assets/images/edit.png")}></Image2>
          <Image3 src={require("../assets/images/delete.png")}></Image3>
        </Group>
        <Image4 src={require("../assets/images/menu_option.png")}></Image4>
      </ImageRow>
    </>
  );
}

const Rect = styled.div`
  width: 1214px;
  height: 64px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(38,105,154,1);
  flex-direction: row;
  display: flex;
  margin-top: 59px;
  border-style: solid;
`;

const SuggestionBoxList = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
`;

const SuggestionBoxList1 = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 24px;
`;

const SuggestionBoxListStack = styled.div`
  width: 213px;
  height: 29px;
  margin-top: 14px;
  position: relative;
`;

const Rect4 = styled.div`
  top: 0px;
  left: 202px;
  width: 42px;
  height: 43px;
  position: absolute;
  background-color: rgba(96,96,96,1);
  flex-direction: column;
  display: flex;
`;

const Rect3 = styled.div`
  width: 42px;
  height: 43px;
  background-color: rgba(145,145,145,1);
  flex-direction: column;
  display: flex;
`;

const Image5 = styled.img`
  width: 23px;
  height: 100%;
  margin-top: 10px;
  margin-left: 10px;
  object-fit: contain;
`;

const MaterialIconTextboxStack = styled.div`
  width: 244px;
  height: 43px;
  margin-left: 352px;
  margin-top: 7px;
  position: relative;
`;

const SuggestionBoxListStackRow = styled.div`
  height: 56px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 12px;
  margin-left: 8px;
  margin-top: 2px;
`;

const TotalSuggestion = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(91,90,90,1);
  font-size: 18px;
  margin-top: 10px;
`;

const TotalSuggestionRow = styled.div`
  height: 43px;
  flex-direction: row;
  display: flex;
  margin-top: 19px;
  margin-left: 8px;
  margin-right: 15px;
`;

const Rect2 = styled.div`
  width: 1207px;
  height: 68px;
  background-color: rgba(81,81,81,1);
  flex-direction: column;
  display: flex;
  margin-top: 16px;
`;

const Box2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: rgba(248,242,242,1);
  font-size: 19px;
  margin-top: 21px;
  margin-left: 115px;
`;

const Image = styled.img`
  width: 100%;
  height: 57px;
  object-fit: contain;
`;

const Box3 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(110,103,103,1);
  font-size: 19px;
  margin-left: 42px;
  margin-top: 28px;
`;

const Group = styled.div`
  width: 180px;
  height: 44px;
  flex-direction: row;
  justify-content: space-between;
  margin-left: 86px;
  margin-top: 10px;
  display: flex;
`;

const Image1 = styled.img`
  width: 100%;
  height: 40px;
  object-fit: contain;
`;

const Image2 = styled.img`
  width: 100%;
  height: 40px;
  object-fit: contain;
`;

const Image3 = styled.img`
  width: 100%;
  height: 40px;
  object-fit: contain;
`;

const Image4 = styled.img`
  width: 100%;
  height: 61px;
  margin-left: 29px;
  object-fit: contain;
`;

const ImageRow = styled.div`
  height: 61px;
  flex-direction: row;
  display: flex;
  margin-top: 9px;
  margin-left: 8px;
  margin-right: 47px;
`;

export default Datagrid;
