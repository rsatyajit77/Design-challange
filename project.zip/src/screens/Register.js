import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox from "../components/MaterialFixedLabelTextbox";
import MaterialFixedLabelTextbox1 from "../components/MaterialFixedLabelTextbox1";
import CupertinoButtonInfo from "../components/CupertinoButtonInfo";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function Register(props) {
  return (
    <Row>
      <Image
        src={require("../assets/images/pexels-photo-3184292.jpeg")}
      ></Image>
      <TextInputColumn>
        <TextInput placeholder="Sign Up"></TextInput>
        <FullName>Full Name</FullName>
        <MaterialFixedLabelTextbox
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(54,53,53,1)",
            marginTop: 12,
            marginLeft: 9,
            borderStyle: "solid"
          }}
          emailAddress="Name"
        ></MaterialFixedLabelTextbox>
        <Email>Email</Email>
        <MaterialFixedLabelTextbox
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(54,53,53,1)",
            marginTop: 20,
            marginLeft: 10,
            borderStyle: "solid"
          }}
          emailAddress="email "
        ></MaterialFixedLabelTextbox>
        <Password>Password</Password>
        <MaterialFixedLabelTextbox1
          label="FixedLabel"
          style={{
            height: 43,
            width: 400,
            marginTop: 16,
            marginLeft: 9
          }}
          label="password"
        ></MaterialFixedLabelTextbox1>
        <LoremIpsum>
          By signing up, you agree to our Terms of Use and {"\n"}acknowledge
          that you read our Privacy Policy
        </LoremIpsum>
        <CupertinoButtonInfoRow>
          <CupertinoButtonInfo
            style={{
              height: 44,
              width: 140,
              backgroundColor: "rgba(63,172,211,1)"
            }}
          ></CupertinoButtonInfo>
          <MaterialButtonPrimary
            style={{
              height: 44,
              width: 140,
              borderWidth: 1,
              borderColor: "rgba(63,172,211,1)",
              marginLeft: 83,
              borderStyle: "solid"
            }}
          ></MaterialButtonPrimary>
        </CupertinoButtonInfoRow>
      </TextInputColumn>
    </Row>
  );
}

const Row = styled.div`
  display: flex;
  height: 800px;
  flex-direction: row;
  margin-top: -26px;
  margin-right: 39px;
`;

const Image = styled.img`
  width: 100%;
  height: 800px;
  object-fit: stretch;
`;

const TextInput = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(51,51,51,1);
  font-size: 44px;
  width: 155px;
  height: 58px;
  margin-left: 9px;
  border: none;
  background: transparent;
`;

const FullName = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(153,153,153,1);
  font-size: 20px;
  margin-top: 34px;
  margin-left: 9px;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(153,153,153,1);
  font-size: 20px;
  margin-top: 41px;
  margin-left: 12px;
`;

const Password = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(153,153,153,1);
  font-size: 20px;
  margin-top: 26px;
  margin-left: 10px;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(85,85,85,1);
  font-size: 16px;
  margin-top: 27px;
`;

const CupertinoButtonInfoRow = styled.div`
  height: 44px;
  flex-direction: row;
  display: flex;
  margin-top: 36px;
  margin-left: 12px;
  margin-right: 35px;
`;

const TextInputColumn = styled.div`
  width: 410px;
  flex-direction: column;
  display: flex;
  margin-left: 117px;
  margin-top: 71px;
  margin-bottom: 166px;
`;

export default Register;
