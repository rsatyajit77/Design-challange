import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox from "../components/MaterialFixedLabelTextbox";
import MaterialFixedLabelTextbox1 from "../components/MaterialFixedLabelTextbox1";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function Login(props) {
  return (
    <Row>
      <Image
        src={require("../assets/images/pexels-photo-3184292.jpeg")}
      ></Image>
      <SignInColumn>
        <SignIn>Sign In</SignIn>
        <Email>Email</Email>
        <MaterialFixedLabelTextbox
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(54,53,53,1)",
            marginTop: 20,
            marginLeft: 1,
            borderStyle: "solid"
          }}
          emailAddress="Enter Email "
        ></MaterialFixedLabelTextbox>
        <Password>Password</Password>
        <MaterialFixedLabelTextbox1
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(67,67,67,1)",
            marginTop: 16,
            borderStyle: "solid"
          }}
          label="Enter Password"
        ></MaterialFixedLabelTextbox1>
        <Group>
          <Forgot placeholder="Forget Password ?"></Forgot>
          <Rect></Rect>
          <Remember placeholder="Remember Me" autoFocus={true}></Remember>
        </Group>
        <MaterialButtonPrimary2Row>
          <MaterialButtonPrimary
            style={{
              height: 44,
              width: 140,
              borderWidth: 1,
              borderColor: "rgba(63,172,211,1)",
              borderStyle: "solid"
            }}
            back="Sign In"
          ></MaterialButtonPrimary>
          <MaterialButtonPrimary
            style={{
              height: 44,
              width: 140,
              borderWidth: 1,
              borderColor: "rgba(63,172,211,1)",
              marginLeft: 71,
              borderStyle: "solid"
            }}
            back="Si"
          ></MaterialButtonPrimary>
        </MaterialButtonPrimary2Row>
      </SignInColumn>
    </Row>
  );
}

const Row = styled.div`
  display: flex;
  height: 800px;
  flex-direction: row;
  margin-top: -26px;
  margin-right: 39px;
`;

const Image = styled.img`
  width: 100%;
  height: 800px;
  object-fit: stretch;
`;

const SignIn = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(51,51,51,1);
  font-size: 44px;
  width: 155px;
  height: 58px;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(153,153,153,1);
  font-size: 20px;
  margin-top: 44px;
  margin-left: 3px;
`;

const Password = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(153,153,153,1);
  font-size: 20px;
  margin-top: 26px;
  margin-left: 1px;
`;

const Group = styled.div`
  width: 400px;
  height: 55px;
  flex-direction: row;
  justify-content: center;
  margin-top: 76px;
  margin-left: 1px;
  position: relative;
  display: flex;
`;

const Forgot = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(85,85,85,1);
  font-size: 16px;
  width: 155px;
  height: 35px;
  padding: 0px;
  margin: 15px;
  border: none;
  background: transparent;
`;

const Rect = styled.div`
  top: 21px;
  left: -2px;
  width: 25px;
  height: 26px;
  position: absolute;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(63,172,211,1);
  border-style: solid;
`;

const Remember = styled.input`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(85,85,85,1);
  font-size: 16px;
  width: 355px;
  height: 35px;
  padding: 10px;
  margin: 15px;
  text-align: left;
  border: none;
  background: transparent;
`;

const MaterialButtonPrimary2Row = styled.div`
  height: 44px;
  flex-direction: row;
  display: flex;
  margin-top: 86px;
  margin-left: 15px;
  margin-right: 35px;
`;

const SignInColumn = styled.div`
  width: 401px;
  flex-direction: column;
  display: flex;
  margin-left: 126px;
  margin-top: 71px;
  margin-bottom: 166px;
`;

export default Login;
