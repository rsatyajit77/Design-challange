import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import Register from "./screens/Register";
import Register1 from "./screens/Register1";
import Login from "./screens/Login";
import "./style.css";

function App() {
  return (
    <Router>
      <Route path="/" exact component={Register} />
      <Route path="/Register/" exact component={Register} />
      <Route path="/Register1/" exact component={Register1} />
      <Route path="/Login/" exact component={Login} />
    </Router>
  );
}

export default App;
