import React, { Component } from "react";
import styled, { css } from "styled-components";

function Menuoption(props) {
  return (
    <Container {...props}>
      <RectStack>
        <Rect></Rect>
        <Rect1></Rect1>
      </RectStack>
      <Rect2></Rect2>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

const Rect = styled.div`
  width: 190px;
  height: 60px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(63,63,63,1);
  position: absolute;
  top: 0px;
  left: 0px;
  border-style: solid;
`;

const Rect1 = styled.div`
  width: 190px;
  height: 60px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(63,63,63,1);
  position: absolute;
  top: 59px;
  left: 0px;
  border-style: solid;
`;

const RectStack = styled.div`
  width: 190px;
  height: 119px;
  position: relative;
`;

const Rect2 = styled.div`
  width: 190px;
  height: 60px;
  background-color: #E6E6E6;
  border-width: 1px;
  border-color: rgba(63,63,63,1);
  border-style: solid;
`;

export default Menuoption;
