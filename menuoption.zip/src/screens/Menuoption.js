import React, { Component } from "react";
import styled, { css } from "styled-components";
import Menuoption from "../components/Menuoption";

function Menuoption(props) {
  return (
    <>
      <MenuoptionStyleStack>
        <Menuoption
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            height: 180,
            width: 156
          }}
        ></Menuoption>
        <Setting>Setting</Setting>
        <Share>Share</Share>
        <Archive2>Archive</Archive2>
        <Image src={require("../assets/images/setting.png")}></Image>
        <Image1 src={require("../assets/images/share.png")}></Image1>
        <Image2 src={require("../assets/images/Arc.png")}></Image2>
      </MenuoptionStyleStack>
      <Archive>Archive</Archive>
    </>
  );
}

const Setting = styled.span`
  font-family: Roboto;
  top: 15px;
  left: 52px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
`;

const Share = styled.span`
  font-family: Roboto;
  top: 78px;
  left: 52px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
`;

const Archive2 = styled.span`
  font-family: Roboto;
  top: 134px;
  left: 52px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
`;

const Image = styled.img`
  top: 15px;
  left: 11px;
  width: 26px;
  height: 26px;
  position: absolute;
  object-fit: contain;
`;

const Image1 = styled.img`
  top: 76px;
  left: 11px;
  width: 26px;
  height: 26px;
  position: absolute;
  object-fit: contain;
`;

const Image2 = styled.img`
  top: 134px;
  left: 11px;
  width: 26px;
  height: 26px;
  position: absolute;
  object-fit: contain;
`;

const MenuoptionStyleStack = styled.div`
  width: 156px;
  height: 180px;
  position: relative;
`;

const Archive = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-top: -455px;
  margin-left: -83px;
`;

export default Menuoption;
