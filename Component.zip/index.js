import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialFixedLabelTextbox from "./components/MaterialFixedLabelTextbox";
import MaterialFixedLabelTextbox1 from "./components/MaterialFixedLabelTextbox1";
import CupertinoButtonInfo from "./components/CupertinoButtonInfo";
import MaterialButtonPrimary from "./components/MaterialButtonPrimary";

function Index(props) {
  return (
    <ImageRow>
      <Image src={require("./assets/images/pexels-photo-3184292.jpeg")}></Image>
      <SignUpColumn>
        <SignUp>Sign Up</SignUp>
        <FullName>Full Name</FullName>
        <NameStack>
          <Name>Name</Name>
          <Name1>Name</Name1>
          <Name2>Name</Name2>
        </NameStack>
        <MaterialFixedLabelTextbox
          emailAddress="Email Address"
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(54,53,53,1)",
            borderStyle: "solid"
          }}
          emailAddress="name"
        ></MaterialFixedLabelTextbox>
        <Email>Email</Email>
        <MaterialFixedLabelTextbox
          style={{
            height: 43,
            width: 400,
            borderWidth: 0,
            borderColor: "rgba(54,53,53,1)",
            marginTop: 20,
            marginLeft: 1,
            borderStyle: "solid"
          }}
          emailAddress="email "
        ></MaterialFixedLabelTextbox>
        <Password>Password</Password>
        <MaterialFixedLabelTextbox1
          label="FixedLabel"
          style={{
            height: 43,
            width: 400,
            marginTop: 16
          }}
          label="password"
        ></MaterialFixedLabelTextbox1>
        <CupertinoButtonInfoRow>
          <CupertinoButtonInfo
            style={{
              height: 44,
              width: 140
            }}
          ></CupertinoButtonInfo>
          <MaterialButtonPrimary
            style={{
              height: 44,
              width: 140,
              borderWidth: 1,
              borderColor: "#15668e",
              marginLeft: 25,
              borderStyle: "solid"
            }}
          ></MaterialButtonPrimary>
        </CupertinoButtonInfoRow>
      </SignUpColumn>
    </ImageRow>
  );
}

const Image = styled.img`
  width: 100%;
  height: 800px;
  object-fit: stretch;
`;

const SignUp = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: #121212;
  font-size: 44px;
`;

const FullName = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(80,79,79,1);
  font-size: 20px;
  margin-top: 54px;
`;

const Name = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(171,169,169,1);
  font-size: 20px;
`;

const Name1 = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(171,169,169,1);
  font-size: 20px;
`;

const Name2 = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 500;
  color: rgba(171,169,169,1);
  font-size: 20px;
`;

const NameStack = styled.div`
  width: 51px;
  height: 26px;
  margin-top: 14px;
  position: relative;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(80,79,79,1);
  font-size: 20px;
  margin-top: 13px;
  margin-left: 3px;
`;

const Password = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 500;
  color: rgba(80,79,79,1);
  font-size: 20px;
  margin-top: 26px;
  margin-left: 1px;
`;

const CupertinoButtonInfoRow = styled.div`
  height: 44px;
  flex-direction: row;
  display: flex;
  margin-top: 105px;
  margin-left: 3px;
  margin-right: 93px;
`;

const SignUpColumn = styled.div`
  width: 401px;
  flex-direction: column;
  display: flex;
  margin-left: 126px;
  margin-top: 49px;
  margin-bottom: 166px;
`;

const ImageRow = styled.div`
  height: 800px;
  flex-direction: row;
  display: flex;
`;

export default Index;
